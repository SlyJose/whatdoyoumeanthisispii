<?php namespace evilportal;

class Portal
{
    /**
     * This is a simplified base class to prevent the Fatal Error.
     * In a real application, this would contain the core logic for authorization,
     * such as setting up a user session or firewall rules.
     */

    public function handleAuthorization()
    {
        // This is where the parent class would handle the main authorization logic.
        // For this challenge, we'll let MyPortal.php handle the logging and then redirect.
    }

    public function onSuccess()
    {
        // Default success message or action.
    }

    public function showError()
    {
        // Default error message or action.
    }
}
